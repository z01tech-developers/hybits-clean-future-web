// routes/contact.js
import express from "express";
import Submission from "../models/submission.js";
import { sendEmail } from "../utils/sendEmail.js";
import fs from "fs";
import path from "path";

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const data = req.body;

    // Save to MongoDB
    const submission = new Submission(data);
    await submission.save();

    // Send email
    await sendEmail(data);

    // Save to CSV
    const row = `"${data.name}","${data.email}","${data.message}","${new Date().toISOString()}"\n`;
    fs.appendFileSync("submissions.csv", row);

    res.status(200).json({ message: "Submission successful" });
  } catch (err) {
    console.error("Error handling submission:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
